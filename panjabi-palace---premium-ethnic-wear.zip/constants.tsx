
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Royal Crimson Silk',
    price: 3450,
    description: 'আভিজাত্য আর ঐতিহ্যের মিশেলে প্রিমিয়াম সিল্কের কাজ করা পাঞ্জাবি।',
    category: 'Silk Collection',
    image: 'https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=800',
    colors: ['Crimson', 'Gold']
  },
  {
    id: 'p2',
    name: 'Classic White Cotton',
    price: 1850,
    description: 'অত্যন্ত আরামদায়ক ১০০% পিওর কটন ফেব্রিক দিয়ে তৈরি যা সারাদিন সতেজ রাখে।',
    category: 'Daily Wear',
    image: 'https://images.unsplash.com/photo-1624371414361-e6e9ee358521?auto=format&fit=crop&q=80&w=800',
    colors: ['White']
  },
  {
    id: 'p3',
    name: 'Deep Blue Embroidered',
    price: 2750,
    description: 'গলায় এবং হাতায় নিখুঁত হাতের কাজের ছোঁয়া যা আপনার লুকে আনবে নতুনত্ব।',
    category: 'Festive Wear',
    image: 'https://images.unsplash.com/photo-1621335829175-95f437384d7c?auto=format&fit=crop&q=80&w=800',
    colors: ['Midnight Blue']
  },
  {
    id: 'p4',
    name: 'Sand Beige Linen',
    price: 2200,
    description: 'লিনেন ফেব্রিকের মার্জিত এই পাঞ্জাবি যেকোনো ঘরোয়া অনুষ্ঠানে পরার জন্য সেরা।',
    category: 'Summer Collection',
    image: 'https://images.unsplash.com/photo-1604904612715-47bf9d9bc670?auto=format&fit=crop&q=80&w=800',
    colors: ['Beige']
  }
];
