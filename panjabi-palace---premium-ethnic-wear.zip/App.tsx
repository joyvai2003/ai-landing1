
import React, { useState, useRef } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProductGrid from './components/ProductGrid';
import OrderForm from './components/OrderForm';
import Footer from './components/Footer';
import StyleAssistant from './components/StyleAssistant';
import { Product } from './types';

const App: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const orderFormRef = useRef<HTMLDivElement>(null);

  const scrollToOrder = (product?: Product) => {
    if (product) setSelectedProduct(product);
    orderFormRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-amber-200">
      <Header />
      
      <main className="flex-grow">
        <Hero onShopNow={() => scrollToOrder()} />
        
        <section id="collection" className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-stone-800 mb-4">
                আমাদের এক্সক্লুসিভ সংগ্রহ
              </h2>
              <div className="w-24 h-1 bg-amber-600 mx-auto rounded-full"></div>
              <p className="mt-4 text-stone-600 max-w-2xl mx-auto">
                আমাদের প্রতিটি পাঞ্জাবি তৈরি করা হয় সেরা মানের ফেব্রিক এবং নিখুঁত কারুকাজ দিয়ে।
              </p>
            </div>
            
            <ProductGrid onSelect={scrollToOrder} />
          </div>
        </section>

        <section id="style-assistant" className="py-20 bg-stone-100">
          <StyleAssistant onProductSuggested={scrollToOrder} />
        </section>

        <section id="order" ref={orderFormRef} className="py-20 bg-stone-900 text-stone-100">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-amber-500 mb-4">
                অর্ডার করুন এখনই
              </h2>
              <p className="text-stone-400">
                নিচের ফর্মটি পূরণ করুন, আমরা আপনার সাথে খুব শীঘ্রই যোগাযোগ করবো।
              </p>
            </div>
            
            <OrderForm initialProduct={selectedProduct} />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default App;
