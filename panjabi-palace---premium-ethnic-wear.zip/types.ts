
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  image: string;
  colors: string[];
}

export interface OrderData {
  customerName: string;
  phone: string;
  address: string;
  productId: string;
  size: string;
  quantity: number;
  notes?: string;
}

export enum Size {
  M = 'M (38)',
  L = 'L (40)',
  XL = 'XL (42)',
  XXL = 'XXL (44)'
}
