
import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-amber-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
            P
          </div>
          <span className={`text-2xl font-serif font-bold tracking-tight ${isScrolled ? 'text-stone-900' : 'text-stone-800'}`}>
            Panjabi <span className="text-amber-600">Palace</span>
          </span>
        </div>
        
        <nav className="hidden md:flex items-center space-x-8 text-sm font-medium">
          {['Collection', 'Style Assistant', 'Order'].map((item) => (
            <a 
              key={item}
              href={`#${item.toLowerCase().replace(' ', '-')}`}
              className={`${isScrolled ? 'text-stone-600 hover:text-amber-600' : 'text-stone-700 hover:text-amber-600'} transition-colors uppercase tracking-wider`}
            >
              {item === 'Collection' ? 'সংগ্রহ' : item === 'Style Assistant' ? 'স্টাইল গাইড' : 'অর্ডার'}
            </a>
          ))}
        </nav>

        <button className="bg-amber-600 text-white px-6 py-2 rounded-full text-sm font-bold hover:bg-amber-700 transition-colors shadow-lg">
          কল করুন
        </button>
      </div>
    </header>
  );
};

export default Header;
