
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-950 text-stone-400 py-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-amber-600 rounded flex items-center justify-center text-white font-bold">P</div>
              <span className="text-xl font-serif font-bold text-white tracking-tight">
                Panjabi <span className="text-amber-600">Palace</span>
              </span>
            </div>
            <p className="max-w-md leading-relaxed">
              আমরা বিশ্বাস করি ফ্যাশন মানেই স্বাচ্ছন্দ্য এবং আত্মবিশ্বাস। আমাদের প্রিমিয়াম পাঞ্জাবি সংগ্রহ আপনার প্রতিটি বিশেষ মুহূর্তকে করবে আরো স্মরণীয়।
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6">যোগাযোগ</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 italic">
                <span>📍</span> হাউজ-১২, রোড-০৫, বনানী, ঢাকা
              </li>
              <li className="flex items-center gap-3">
                <span>📞</span> +৮৮০ ১৭০০-০০০০০০
              </li>
              <li className="flex items-center gap-3">
                <span>✉️</span> info@panjabipalace.com
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">সামাজিক যোগাযোগ</h4>
            <div className="flex gap-4">
              {['FB', 'IG', 'YT'].map(social => (
                <a key={social} href="#" className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center hover:bg-amber-600 hover:text-white transition-all">
                  {social}
                </a>
              ))}
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-stone-900 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
          <p>© ২০২৪ পাঞ্জাবি প্যালেস। সর্বস্বত্ব সংরক্ষিত।</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-amber-500">গোপনীয়তা নীতি</a>
            <a href="#" className="hover:text-amber-500">রিফান্ড পলিসি</a>
            <a href="#" className="hover:text-amber-500">শর্তাবলী</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
