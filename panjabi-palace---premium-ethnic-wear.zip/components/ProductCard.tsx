
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  return (
    <div className="group bg-stone-50 rounded-2xl overflow-hidden border border-stone-200 transition-all hover:shadow-2xl">
      <div className="relative aspect-[4/5] overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 right-4">
          <span className="bg-amber-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
            Premium
          </span>
        </div>
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
           <button 
            onClick={() => onSelect(product)}
            className="bg-white text-stone-900 px-6 py-2 rounded-full font-bold shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-all"
           >
             অর্ডার করুন
           </button>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <div>
            <span className="text-amber-600 text-xs font-bold uppercase tracking-widest">{product.category}</span>
            <h3 className="text-xl font-bold text-stone-800 mt-1">{product.name}</h3>
          </div>
          <p className="text-lg font-bold text-amber-700">৳{product.price}</p>
        </div>
        <p className="text-stone-600 text-sm line-clamp-2 mb-4 leading-relaxed">
          {product.description}
        </p>
        <div className="flex items-center gap-2">
          <div className="flex -space-x-2">
            {product.colors.map((c, i) => (
              <div key={i} className={`w-4 h-4 rounded-full border border-white shadow-sm bg-${c.toLowerCase()}-500`} style={{backgroundColor: c}}></div>
            ))}
          </div>
          <span className="text-xs text-stone-400">{product.colors.length} Colors Available</span>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
