
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Product } from '../types';
import { PRODUCTS } from '../constants';

interface StyleAssistantProps {
  onProductSuggested: (product: Product) => void;
}

const StyleAssistant: React.FC<StyleAssistantProps> = ({ onProductSuggested }) => {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [occasion, setOccasion] = useState('');
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<string | null>(null);

  const getAdvice = async () => {
    if (!height || !weight || !occasion) return;
    setLoading(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `I am looking for style advice for a Panjabi. My height is ${height}cm, weight is ${weight}kg, and I'm attending a ${occasion}. 
                   Based on these available products: ${PRODUCTS.map(p => p.name).join(', ')}, recommend one and give 2-3 short style tips in Bengali.`,
        config: {
          temperature: 0.7,
        }
      });
      
      setSuggestion(response.text || "দুঃখিত, এই মুহূর্তে পরামর্শ দেওয়া সম্ভব হচ্ছে না।");
    } catch (error) {
      console.error(error);
      setSuggestion("পাঞ্জাবি বাছাই করার জন্য গাঢ় রঙের ফেব্রিক এবং মানানসই নাগরা জুতা পরতে পারেন।");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-white rounded-3xl overflow-hidden shadow-xl flex flex-col md:flex-row">
        <div className="md:w-1/2 p-8 md:p-12 bg-amber-600 text-white">
          <h2 className="text-3xl font-serif font-bold mb-6">আপনার জন্য সেরা পাঞ্জাবি কোনটি?</h2>
          <p className="text-amber-100 mb-8 leading-relaxed">
            আমাদের স্মার্ট স্টাইল অ্যাসিস্ট্যান্ট আপনার উচ্চতা, ওজন এবং অনুষ্ঠানের ধরন অনুযায়ী আপনাকে সেরা স্টাইল টিপস দিবে।
          </p>
          
          <div className="space-y-4">
            <div className="flex gap-4">
              <input 
                type="number" 
                placeholder="উচ্চতা (cm)" 
                className="w-1/2 bg-amber-700 border-none rounded-xl px-4 py-3 placeholder-amber-300 text-white focus:ring-2 focus:ring-white"
                value={height}
                onChange={e => setHeight(e.target.value)}
              />
              <input 
                type="number" 
                placeholder="ওজন (kg)" 
                className="w-1/2 bg-amber-700 border-none rounded-xl px-4 py-3 placeholder-amber-300 text-white focus:ring-2 focus:ring-white"
                value={weight}
                onChange={e => setWeight(e.target.value)}
              />
            </div>
            <select 
              className="w-full bg-amber-700 border-none rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-white appearance-none"
              value={occasion}
              onChange={e => setOccasion(e.target.value)}
            >
              <option value="">অনুষ্ঠান বাছাই করুন</option>
              <option value="Wedding">বিয়ে বাড়ি</option>
              <option value="Eid">ঈদ উৎসব</option>
              <option value="Casual Office">অফিস/ক্যাজুয়াল</option>
              <option value="Party">পার্টি</option>
            </select>
            
            <button 
              onClick={getAdvice}
              disabled={loading || !height || !weight || !occasion}
              className="w-full bg-white text-amber-600 font-bold py-4 rounded-xl hover:bg-amber-50 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? "ভাবছি..." : "ম্যাজিক দেখুন ✨"}
            </button>
          </div>
        </div>

        <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center bg-stone-50">
          {!suggestion ? (
            <div className="text-center">
              <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">💡</div>
              <h3 className="text-xl font-bold text-stone-800 mb-2">স্টাইল টিপস পেতে বামদিকের ফর্মটি পূরণ করুন</h3>
              <p className="text-stone-500">আপনার বডি টাইপ অনুযায়ী সেরা সাজেশন এখানে প্রদর্শিত হবে।</p>
            </div>
          ) : (
            <div className="animate-fade-in">
              <h3 className="text-xl font-bold text-stone-800 mb-4 flex items-center gap-2">
                <span className="text-amber-600 text-2xl">✨</span> আমাদের পরামর্শ
              </h3>
              <div className="prose prose-stone text-stone-700 leading-relaxed whitespace-pre-line">
                {suggestion}
              </div>
              <div className="mt-8 flex gap-3">
                 <button 
                  onClick={() => setSuggestion(null)}
                  className="text-stone-500 text-sm font-medium hover:text-amber-600"
                 >
                   আবার ট্রাই করুন
                 </button>
                 <button 
                  onClick={() => onProductSuggested(PRODUCTS[0])}
                  className="bg-amber-600 text-white text-sm font-bold px-6 py-2 rounded-full hover:bg-amber-700"
                 >
                   অর্ডার ফর্ম-এ যান
                 </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StyleAssistant;
