
import React, { useState, useEffect } from 'react';
import { Product, Size, OrderData } from '../types';
import { PRODUCTS } from '../constants';

interface OrderFormProps {
  initialProduct: Product | null;
}

const OrderForm: React.FC<OrderFormProps> = ({ initialProduct }) => {
  const [formData, setFormData] = useState<Partial<OrderData>>({
    productId: initialProduct?.id || '',
    size: Size.L,
    quantity: 1
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (initialProduct) {
      setFormData(prev => ({ ...prev, productId: initialProduct.id }));
    }
  }, [initialProduct]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSuccess(true);
    
    // Clear success message after 5 seconds
    setTimeout(() => setIsSuccess(false), 5000);
  };

  const selectedProduct = PRODUCTS.find(p => p.id === formData.productId);

  if (isSuccess) {
    return (
      <div className="bg-green-900/20 border border-green-500/50 p-12 rounded-3xl text-center">
        <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">অর্ডার সফল হয়েছে!</h3>
        <p className="text-stone-300">আমরা শীঘ্রই আপনার দেওয়া নাম্বারে কল করে কনফার্ম করবো। ধন্যবাদ!</p>
        <button 
          onClick={() => setIsSuccess(false)}
          className="mt-8 text-amber-500 font-bold hover:underline"
        >
          আরেকটি অর্ডার করুন
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-stone-800/50 p-8 md:p-12 rounded-3xl border border-stone-700 backdrop-blur-sm">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-stone-400 mb-1">আপনার নাম</label>
            <input 
              required
              type="text"
              placeholder="যেমন: আরিয়ান খান"
              className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all"
              onChange={e => setFormData({...formData, customerName: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-400 mb-1">মোবাইল নাম্বার</label>
            <input 
              required
              type="tel"
              placeholder="017XXXXXXXX"
              className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all"
              onChange={e => setFormData({...formData, phone: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-400 mb-1">পুরো ঠিকানা</label>
            <textarea 
              required
              placeholder="বাসা নং, রোড নং, এলাকা, জেলা"
              rows={3}
              className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all"
              onChange={e => setFormData({...formData, address: e.target.value})}
            ></textarea>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-stone-400 mb-1">পাঞ্জাবি পছন্দ করুন</label>
            <select 
              value={formData.productId}
              className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all"
              onChange={e => setFormData({...formData, productId: e.target.value})}
            >
              <option value="">সিলেক্ট করুন</option>
              {PRODUCTS.map(p => (
                <option key={p.id} value={p.id}>{p.name} - ৳{p.price}</option>
              ))}
            </select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-stone-400 mb-1">সাইজ</label>
              <select 
                className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all"
                onChange={e => setFormData({...formData, size: e.target.value})}
              >
                {Object.values(Size).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-stone-400 mb-1">পরিমাণ</label>
              <input 
                type="number"
                min="1"
                defaultValue="1"
                className="w-full bg-stone-900 border border-stone-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 transition-all"
                onChange={e => setFormData({...formData, quantity: parseInt(e.target.value)})}
              />
            </div>
          </div>

          <div className="bg-stone-900/50 p-4 rounded-xl border border-stone-700">
             <div className="flex justify-between items-center mb-2">
               <span className="text-stone-400">সাব-টোটাল:</span>
               <span className="text-white font-bold">৳{(selectedProduct?.price || 0) * (formData.quantity || 1)}</span>
             </div>
             <div className="flex justify-between items-center text-sm">
               <span className="text-stone-500">ডেলিভারি চার্জ:</span>
               <span className="text-green-500">ফ্রি (সীমিত সময়ের জন্য)</span>
             </div>
             <hr className="my-3 border-stone-700" />
             <div className="flex justify-between items-center">
               <span className="text-lg font-bold text-amber-500">মোট:</span>
               <span className="text-2xl font-bold text-amber-500">৳{(selectedProduct?.price || 0) * (formData.quantity || 1)}</span>
             </div>
          </div>
        </div>
      </div>

      <button 
        disabled={isSubmitting}
        className="w-full bg-amber-600 hover:bg-amber-700 disabled:bg-stone-600 text-white font-bold py-4 rounded-xl text-lg transition-all transform hover:scale-[1.01] active:scale-[0.99] shadow-2xl flex items-center justify-center gap-3"
      >
        {isSubmitting ? (
          <>
            <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            প্রসেস করা হচ্ছে...
          </>
        ) : 'অর্ডার কনফার্ম করুন'}
      </button>
      
      <p className="text-center text-stone-500 text-sm">
        * ঢাকা এবং ঢাকার বাইরে ক্যাশ অন ডেলিভারি সুবিধা আছে।
      </p>
    </form>
  );
};

export default OrderForm;
