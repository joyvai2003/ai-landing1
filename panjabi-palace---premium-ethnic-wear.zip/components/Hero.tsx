
import React from 'react';

interface HeroProps {
  onShopNow: () => void;
}

const Hero: React.FC<HeroProps> = ({ onShopNow }) => {
  return (
    <div className="relative h-screen min-h-[600px] overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=1920" 
          alt="Luxury Panjabi" 
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"></div>
      </div>

      <div className="relative z-10 h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <span className="inline-block text-amber-400 font-bold tracking-[0.2em] mb-4 animate-fade-in uppercase">
              Limited Edition 2024
            </span>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-6 leading-tight">
              আপনার আভিজাত্যের <br /> 
              <span className="text-amber-500 italic">অনন্য প্রতীক</span>
            </h1>
            <p className="text-lg text-stone-200 mb-8 leading-relaxed max-w-lg">
              ঐতিহ্যবাহী নকশা আর আধুনিক ছোঁয়ায় তৈরি আমাদের প্রতিটি পাঞ্জাবি আপনার ব্যক্তিত্বকে করবে আরো উজ্জ্বল। এখন ইদ ধামাকা অফার চলছে!
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={onShopNow}
                className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-xl"
              >
                এখনই সংগ্রহ দেখুন
              </button>
              <button 
                className="border-2 border-white/30 hover:border-white text-white px-8 py-4 rounded-full text-lg font-bold transition-all backdrop-blur-md"
              >
                ক্যাটালগ ডাউনলোড
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-white rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
